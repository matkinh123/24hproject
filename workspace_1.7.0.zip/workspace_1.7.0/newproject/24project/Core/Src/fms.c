/*
 * fsm_simple_buttons_run.c
 *
 *  Created on: Nov 5, 2022
 *      Author: hotha
 */

#include "fms.h"
int numDisplay = 0;
int RESET_Button = NORMAL_STATE;
int INC_Button = NORMAL_STATE;
int DEC_Button = NORMAL_STATE;
int countDown_flag = 0;
int countDownTime = 0;
void countDownTimeRun(){
	if(countDownTime > 0){
		countDownTime--;
		if(countDownTime <= 0)
			countDown_flag = 1;
	}
}
void fms_simple_button_run (){
	RESETInput();
	INCInput();
	DECInput();
	display7SEG(numDisplay);
}

/*
 * button.c
 *
 *  Created on: Nov 4, 2022
 *      Author: hotha
 */

#include "button.h"
int keyReg0 = NORMAL_STATE;
int keyReg1 = NORMAL_STATE;
int keyReg2 = NORMAL_STATE;
int keyReg3 = NORMAL_STATE;
int keyReg4 = NORMAL_STATE;
int keyReg5 = NORMAL_STATE;
int timeForRESET = 300;
int timeForINC = 300;
int timeForDEC = 300;
void RESETInput(){
	if(HAL_GPIO_ReadPin(RESET_GPIO_Port, RESET_Pin)== PRESSED_STATE){
		if(countDown_flag == 0) countDownTime = 1000;
		else{
			countDown_flag = 0;
			countDownTime = 1000;
		}
		numDisplay = 0;
		display7SEG(numDisplay);
	}
}
void INCInput(){
	keyReg0 = keyReg1;
	keyReg1 = HAL_GPIO_ReadPin(INC_GPIO_Port, INC_Pin);
	if(keyReg0 == keyReg1){
		if(keyReg2 != keyReg1){
			keyReg2 = keyReg1;
			if(keyReg1 == PRESSED_STATE){
				if(countDown_flag == 0) countDownTime = 1000;
				else{
					countDown_flag = 0;
					countDownTime = 1000;
				}
				numDisplay++;
				if(numDisplay > 9) numDisplay = 0;
				display7SEG(numDisplay);
				setTimer2(300);
			}
		}else{
			if(timer2_flag == 1){
				if(keyReg1 == PRESSED_STATE){
					numDisplay++;
					if(numDisplay > 9) numDisplay = 0;
					display7SEG(numDisplay);
				}
				setTimer2(100);
			}
		}
	}
}
void DECInput(){
	keyReg3 = keyReg4;
	keyReg4 = HAL_GPIO_ReadPin(DEC_GPIO_Port, DEC_Pin);
	if(keyReg3 == keyReg4){
		if(keyReg5 != keyReg4){
			keyReg5 = keyReg4;
			if(keyReg4 == PRESSED_STATE){
				if(countDown_flag == 0) countDownTime = 1000;
				else{
					countDown_flag = 0;
					countDownTime = 1000;
				}
				numDisplay--;
				if(numDisplay < 0) numDisplay = 9;
				display7SEG(numDisplay);
				setTimer3(300);
			}
		}else{
			if(timer3_flag == 1){
				if(keyReg4 == PRESSED_STATE){
					numDisplay--;
					if(numDisplay < 0) numDisplay = 9;
					display7SEG(numDisplay);
				}
				setTimer3(100);
			}
		}
	}
}


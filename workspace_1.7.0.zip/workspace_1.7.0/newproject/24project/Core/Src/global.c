/*
 * global.c
 *
 *  Created on: Nov 4, 2022
 *      Author: hotha
 */
#include "global.h"

int status = 0;


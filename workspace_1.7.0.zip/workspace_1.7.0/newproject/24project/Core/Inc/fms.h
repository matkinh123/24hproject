/*
 * fsm_simple_buttons_run.h
 *
 *  Created on: Nov 5, 2022
 *      Author: hotha
 */

#ifndef INC_FSM_H_
#define INC_FSM_H_
#include "global.h"
extern int numDisplay;
extern int RESET_Button;
extern int INC_Button;
extern int DEC_Button;
extern int countDown_flag;
extern int countDownTime;
void countDownTimeRun();
void fms_simple_button_run ();

#endif /* INC_FSM_H_ */

/*
 * display7SegmentLed.h
 *
 *  Created on: Nov 4, 2022
 *      Author: hotha
 */
#ifndef INC_DISPLAY7SEGMENTLED_H_
#define INC_DISPLAY7SEGMENTLED_H_
#include "main.h"
void display7SEG(int num);
#endif /* INC_DISPLAY7SEGMENTLED_H_ */

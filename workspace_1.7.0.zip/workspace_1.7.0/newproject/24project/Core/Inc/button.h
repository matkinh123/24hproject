/*
 * button.h
 *
 *  Created on: Nov 4, 2022
 *      Author: hotha
 */

#ifndef INC_BUTTON_H_
#define INC_BUTTON_H_
#include "main.h"
#include "fms.h"
#define NORMAL_STATE GPIO_PIN_SET
#define PRESSED_STATE GPIO_PIN_RESET
extern int keyReg0;
extern int keyReg1;
extern int keyReg2;
extern int keyReg3;
extern int keyReg4;
extern int keyReg5;
void RESETInput();
void INCInput();
void DECInput();
#endif /* INC_BUTTON_H_ */
